import "./App.css";

function App() {
  return (
    <>
      <form>
        <label>
          Enter Text for Translation
          <input type="text" name="name" />
        </label>
        <input type="submit" value="Submit" />
      </form>
    </>
  );
}
export default App;
